class exemplo_01 {

     public static void main(String[] args) {


         System.out.print ("Olá mundo!\n\n");
         
          int idade;
          idade = 15;

          System.out.println ("idade:  " + idade);

        String nome;
        nome = "Lucas";

           System.out.println ("nome: " + nome);

        Boolean status_aluno;
        status_aluno = true;

            System.out.println ("status_aluno: " + status_aluno);

           char periodo;
           periodo = '2';
            
                System.out.println ("periodo " + periodo);







           






     }




}

//status_aluno  (boolean)

//periodo (char) ''

// System.out.print (exibir)
           // \n\n (quebra a linha)